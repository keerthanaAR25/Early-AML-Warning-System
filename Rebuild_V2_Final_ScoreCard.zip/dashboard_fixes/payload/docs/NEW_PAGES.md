# NEW PAGES AND WARNING CARDS

Everything comes from two files written by `python scripts/rebuild_v2.py export`: `results/warnings.json` and `results/pattern_evidence.json`,
served by `/api/warnings` and `/api/pattern-evidence`. They are built from the same candidates and scores as the rest of the dashboard, and tests check that they agree
with the Lead-Time page (alerts given, rings evaluable, rings seen, rings warned before completion, per-ring lead).

| Page | What it answers |
|---|---|
| **Warning Timeline** | Where the early warning and the alert were given on every ring. Rings are aligned at the day they are complete; a blue dot is the first day a candidate holding the ring existed, an orange triangle the day such a candidate reached the alert threshold. Cards: rings seen, warned before / at / after completion, not seen, median leads, coverage, ring lifetime; a table of every evaluable ring with a status filter; why the other rings cannot be evaluated. |
| **Alert Log** | Every alert given: date, candidate, score at alert and now, patterns, accounts, evidence at the time, days after creation, and (evaluation only) the ring it holds and the lead. A weekly chart of alerts against ring completions. Filter by outcome. |
| **Pattern Evidence** | The pattern investigation (see PATTERN_INVESTIGATION.md): candidates by number and kind of pattern, what makes up the score, what each pattern adds, pattern count against evidence size, and every multi-pattern candidate. |

Also changed: **Ring Investigation** has a "Warning given" card with the alert date, the score history against the threshold, and (evaluation only) the ring and the lead;
**Alert Queue** has an "Alerts given" card and an Alert column; **Overview** has four warning cards. The Investigate buttons now open the candidate you clicked
(they used to open the top-ranked one whatever you clicked).

Ring fields (id, type, first transaction, completion, lead, coverage) are AMLSim ground truth and are used only to evaluate; they never enter a candidate or a score.


## Score calculation card (Temporal Evolution)

For the selected candidate it shows how the 0-100 risk score was worked out: each of the four components with the way its value came from **this candidate's own evidence**
(for example "35 x ln(1 + 3 x 7 evidence transactions / 7 accounts) = 48.5"), its weight, the points it adds, and the total, which is exactly the score. It states whether the score
is at or above the alert threshold, and if an alert was given earlier and the score has since fallen it says so. Below that, the same calculation is shown for every day the candidate
gained evidence (with the day of the alert highlighted), so you can see the score move as evidence accumulates.

The calculation is written by the scoring code itself (`results/score_calculation.json`) from its own constants and the inputs it recorded, and tests recompute the persistence and fund-flow
values independently for all 171 candidates. The behavioural value comes from a model trained only on earlier data, so its inputs are not shown. It needs `python scripts/rebuild_v2.py scoring`
once (about a minute) so the scorer records its inputs; the export tells you if you forget.
